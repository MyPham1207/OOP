#pragma once
#include "Gate.h"

class IntelligenceGate :public Gate
{
private:
	int iPhilosopherIQ;
public:
	IntelligenceGate()
	{
		iType = 2;
		iPhilosopherIQ = 0;
	}

	~IntelligenceGate(){}

	void Input()
	{
		cout << "Type the philosopher's IQ: ";
		cin >> iPhilosopherIQ;
	}

	int Return()
	{
		return iPhilosopherIQ;
	}
};
