#pragma once
#include "Gate.h"

class BussinessGate :public Gate
{
private:
	int iGoodAmount;
	int iPrice;
public:
	BussinessGate()
	{
		iType = 1;
		iGoodAmount = 0;
		iPrice = 0;
	}

	~BussinessGate(){}

	void Input()
	{
		cout << "Type good amount: ";
		cin >> iGoodAmount;
		cout << "Type price: ";
		cin >> iPrice;
	}

	int Return()
	{
		return iGoodAmount * iPrice;
	}

};
