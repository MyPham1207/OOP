#pragma once
#include "Gate.h"

class PowerGate :public Gate
{
private:
	int iHeroPower;
public:
	PowerGate()
	{
		iType = 3;
		iHeroPower = 0;
	}

	~PowerGate(){}

	void Input()
	{
		cout << "Type the hero's power: ";
		cin >> iHeroPower;
	}

	int Return()
	{
		return iHeroPower;
	}
};
