#include "BussinessGate.h"
#include "IntelligenceGate.h"
#include "PowerGate.h"

int main()
{
	int iGateAmount;
	cout << "Type gate amount: ";
	cin >> iGateAmount;
	Gate** list = new Gate * [iGateAmount];
	int iType = 0;
	for (int i = 0; i < iGateAmount; i++)
	{
		cout << "Type of Gate (1: BussinessGate, 2: IntelligenceGate, 3: PowerGate): ";
		cin >> iType;
		if (iType == 1)
		{
			list[i] = new BussinessGate();
			list[i]->Input();
		}
		if (iType == 2)
		{
			list[i] = new IntelligenceGate();
			list[i]->Input();
		}
		if (iType == 3)
		{
			list[i] = new PowerGate();
			list[i]->Input();
		}
	}

	int iMoney, iIQ, iPower;
	cout << "Type money amount, IQ and power of the prince: ";
	cin >> iMoney >> iIQ >> iPower;

	for (int i = 0; i < iGateAmount; i++)
	{
		if (list[i]->getType() == 1)
		{
			if (iMoney < list[i]->Return())
			{
				cout << -1;
				system("pause");
				return 0;
			}
			else
			{
				iMoney -= list[i]->Return();
			}
		}

		if (list[i]->getType() == 2 && iIQ < list[i]->Return())
		{
			cout << -1;
			system("pause");
			return 0;
		}

		if (list[i]->getType() == 3)
		{
			if (iPower < list[i]->Return())
			{
				cout << -1;
				system("pause");
				return 0;
			}
			else
			{
				iPower -= list[i]->Return();
			}
		}
	}

	cout << iMoney << " " << iIQ << " " << iPower;

	system("pause");
	return 0;
}