#pragma once

#include <iostream>
#include <string>
using namespace std;

class Gate
{
protected:
	int iType;
public:
	Gate()
	{
		iType = 0;
	}

	~Gate(){}

	virtual void Input() = 0;

	virtual int Return() = 0;

	int getType()
	{
		return iType;
	}
};